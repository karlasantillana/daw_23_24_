<?php

class Usuario extends \CRUD
{
    public string $nombre;
    public string $apellido;
    public string $sexo;
    public string $direccion;
    public string $telefono;


    static function getTableName(): string
    {
        return "usuarios";
    }

    public function __toString(): string
    {
        return $this->nombre. " " . $this->apellido. " " . $this->sexo;
    }
}