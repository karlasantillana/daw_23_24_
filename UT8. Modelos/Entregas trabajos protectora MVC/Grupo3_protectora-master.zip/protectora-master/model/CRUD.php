<?php
include '../controller/connection.php';
global $pdo;

abstract class CRUD
{

    public int $id;

    abstract static function getTableName(): string;

    static function getUnique(array $filters = []): static
    {
        global $pdo;
        $nFilters = [];
        $tableName = static::getTableName();
        $sql = "SELECT * FROM $tableName";
        if (!empty($filters)) {
            $sql .= ' WHERE ';
            $sql .= implode(" AND ", array_map(function ($value) {
                return "$value = :$value";
            }, array_keys($filters)));
            foreach ($filters as $key => $value) {
                $newKey = ':' . $key;
                $nFilters[$newKey] = $value;
            }
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute($nFilters);
        $stmt->setFetchMode(PDO::FETCH_CLASS, static::class);
        return $stmt->fetch();
    }

    static function getAll(array $filters = []): array
    {
        global $pdo;
        $nFilters = [];
        $tableName = static::getTableName();
        $sql = "SELECT * FROM $tableName";
        if (!empty($filters)) {
            $sql .= ' WHERE ';
            $sql .= implode(" AND ", array_map(function ($value) {
                return "$value LIKE :$value";
            }, array_keys($filters)));
            foreach ($filters as $key => $value) {
                $newKey = ':' . $key;
                $nFilters[$newKey] = "%$value%";
            }
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute($nFilters);
        $stmt->setFetchMode(PDO::FETCH_CLASS, static::class);
        return $stmt->fetchAll();
    }

    public static function getDataType(): array
    {
        global $pdo;
        $sql = "SELECT C.COLUMN_NAME, 
                    C.IS_NULLABLE,
                    C.COLUMN_TYPE,
                    KCU.REFERENCED_TABLE_NAME,
                    KCU.REFERENCED_COLUMN_NAME,
                    C.COLUMN_KEY
                FROM information_schema.COLUMNS AS C
                     LEFT JOIN
                         information_schema.KEY_COLUMN_USAGE AS KCU ON C.TABLE_SCHEMA = KCU.TABLE_SCHEMA
                             AND C.TABLE_NAME = KCU.TABLE_NAME
                             AND C.COLUMN_NAME = KCU.COLUMN_NAME
                WHERE C.TABLE_NAME = :table
                ORDER BY C.ORDINAL_POSITION";

        $stmt = $pdo->prepare($sql);
        $tableName = static::getTableName();
        $stmt->bindParam(":table", $tableName);
        $stmt->execute();


        $tableClass = [];
        foreach (get_declared_classes() as $className) {
            if (is_subclass_of($className, CRUD::class)) {
                $tableClass[$className::getTableName()] = $className;
            }
        }

        $arr = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return array_map(function ($columnTable) use ($tableClass) {
            $tableName = $columnTable["REFERENCED_TABLE_NAME"];
            if (isset($tableClass[$tableName])) {
                $columnTable["CLASS_NAME"] = $tableClass[$tableName];
            }
            return $columnTable;
        }, $arr);
    }

    public static function getReferences(): array
    {
        global $pdo;
        $sql = "SELECT COLUMN_NAME, TABLE_NAME, REFERENCED_COLUMN_NAME
            FROM information_schema.KEY_COLUMN_USAGE
            WHERE REFERENCED_TABLE_NAME = :table AND TABLE_SCHEMA = 'protectora_animales'";

        $stmt = $pdo->prepare($sql);
        $tableName = static::getTableName();
        $stmt->bindParam(":table", $tableName);
        $stmt->execute();


        $tableClass = [];
        foreach (get_declared_classes() as $className) {
            if (is_subclass_of($className, CRUD::class)) {
                $tableClass[$className::getTableName()] = $className;
            }
        }
        $arr = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return array_map(function ($columnTable) use ($tableClass) {
            $tableName = $columnTable["TABLE_NAME"];
            if (isset($tableClass[$tableName])) {
                $columnTable["CLASS_NAME"] = $tableClass[$tableName];
            }
            return $columnTable;
        }, $arr);
    }

    abstract public function __toString(): string;

    function __set($name, $value){
        $this->$name = $value;
    }

    public function update (array $changes): bool
    {
        global $pdo;
        $tableName = static::getTableName();
        $setClause = implode(", ", array_map(function ($column) {
            return "$column = :$column";
        }, array_keys($changes)));

        $sql = "UPDATE $tableName SET $setClause WHERE id = :id";
        $changes['id'] = $this->id;

        $nValues = [];
        foreach ($changes as $key => $value) {
            $newKey = ':' . $key;
            $nValues[$newKey] = $value;
        }
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($nValues);
    }

    public function delete (): bool {
        global $pdo;
        $tableName = static::getTableName();
        $sql = "DELETE FROM $tableName WHERE id = :id";

        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id', $this->id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public static function insert (array $values): bool
    {
        global $pdo;
        $tableName = static::getTableName();
        $columns = implode(", ", array_keys($values));
        $placeholders = ":" . implode(", :", array_keys($values));

        $sql = "INSERT INTO $tableName ($columns) VALUES ($placeholders)";

        $nValues = [];
        foreach ($values as $key => $value) {
            $newKey = ':' . $key;
            $nValues[$newKey] = $value;
        }
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($nValues);
    }
}