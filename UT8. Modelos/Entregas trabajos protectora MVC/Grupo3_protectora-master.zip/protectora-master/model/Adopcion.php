<?php

class Adopcion extends \CRUD
{
    public string $nombre;
    public int $idAnimal;
    public int $idUsuario;
    public $fecha;
    public string $razon;


    static function getTableName(): string
    {
        return "adopcion";
    }

    public function __toString(): string
    {
        return $this->fecha;
    }
}