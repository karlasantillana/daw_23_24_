<?php

class Animal extends \CRUD
{
    public string $nombre;
    public $especie;
    public $raza;
    public $genero;
    public $color;
    public $edad;


    static function getTableName(): string
    {
        return "animal";
    }

    public function __toString(): string
    {
        return $this->nombre;
    }
}