<?php
function tableView(string|CRUD $class, array $list, array $filters): void
{
    $dataTypes = $class::getDataType();
    $relations = $class::getReferences();
    ?>
    <table class="table table-striped" id="table">
        <thead class="thead-dark">
        <tr>
            <?php foreach ($dataTypes as $dataType): ?>
                <th>
                    <span><?= strtoupper($dataType["COLUMN_NAME"]) ?></span>
                    <br>
                    <input type="search" class="form-control" name="<?= $dataType["COLUMN_NAME"] ?>" placeholder="Search" value="<?= isset($filters[$dataType["COLUMN_NAME"]]) ? str_replace("%", "", $filters[$dataType["COLUMN_NAME"]]) : "" ?>">
                </th>
            <?php endforeach; ?>
            <?php foreach ($relations as $relation): ?>
                <?php
                $relationClassName = $relation["CLASS_NAME"];
                ?>
                <th>
                    <span>N <?= strtoupper($relationClassName) ?></span>
                </th>
            <?php endforeach; ?>
            <th>ACCIONES</th>
            <td>

                <a class="btn btn-primary" href="<?= $_SERVER["SCRIPT_NAME"] ?>?type=view_insert&class=<?= $class ?>">Añadir</a>
                <button class="btn btn-primary" onclick="search()">Buscar</button>
            </td>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($list as $item): ?>
            <?php $itemArray = (array)$item; ?>
            <tr>
                <?php foreach ($dataTypes as $dataType): ?>
                    <?php if (isset($dataType["REFERENCED_TABLE_NAME"])): ?>
                        <?php /** @var string|CRUD $relationClassName */
                        $relationClassName = $dataType["CLASS_NAME"];
                        $relationColumnName = $dataType["REFERENCED_COLUMN_NAME"];
                        $filters = [$relationColumnName => $itemArray[$dataType["COLUMN_NAME"]]];
                        ?>
                        <td>
                            <a href="<?= $_SERVER["SCRIPT_NAME"] ?>?type=view_get&class=<?= $relationClassName ?>&filters=<?= urlencode(json_encode($filters)) ?>">
                                <?= $itemArray[$dataType["COLUMN_NAME"]] . " => " . $relationClassName::getUnique($filters) ?>
                            </a>
                        </td>
                    <?php else: ?>
                        <td><?= $itemArray[$dataType["COLUMN_NAME"]] ?></td>
                    <?php endif; ?>
                <?php endforeach; ?>
                <?php foreach ($relations as $relation): ?>
                    <?php /** @var string|CRUD $relationClassName */
                    $relationClassName = $relation["CLASS_NAME"];
                    $relationColumnName = $relation["REFERENCED_COLUMN_NAME"];
                    $filters = [$relation["COLUMN_NAME"] => $itemArray[$relationColumnName]];
                    ?>
                    <td>
                        <a href="<?= $_SERVER["SCRIPT_NAME"] ?>?type=view_getAll&class=<?= $relationClassName ?>&filters=<?= urlencode(json_encode($filters)) ?>"><?= count($relationClassName::getAll($filters)) ?></a>
                    </td>
                <?php endforeach; ?>
                <td>
                    <a class="btn btn-primary"
                       href="<?= $_SERVER["SCRIPT_NAME"] ?>?type=view_update&class=<?= $class ?>&filters=<?= urlencode(json_encode(["id" => $item->id])) ?>">Actualizar</a>
                    <a class="btn btn-danger"
                       href="<?= $_SERVER["SCRIPT_NAME"] ?>?type=delete&class=<?= $class ?>&filters=<?= urlencode(json_encode(["id" => $item->id])) ?>">Borrar</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <script>
        const table = document.getElementById('table');
        function search() {
            const inputs = table.querySelectorAll('[name]');
            const formData = {};
            inputs.forEach(function(input) {
                const name = input.getAttribute('name');
                formData[name] = `%${input.value}%`;
            });
            const jsonString = JSON.stringify(formData);
            window.location = `<?= $_SERVER["SCRIPT_NAME"] ?>?type=view_getAll&class=<?= $class ?>&filters=${encodeURIComponent(jsonString)}`;
        }
    </script>
    <?php
}