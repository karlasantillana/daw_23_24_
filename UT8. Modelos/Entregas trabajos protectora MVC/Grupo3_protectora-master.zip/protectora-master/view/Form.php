<?php
function createInput(array $dataType, bool $readOnly, string|null $value = null): void
{
    $colName = $dataType["COLUMN_NAME"] ?>
    <div class="form-group">
        <label class="font-weight-bold" for="<?= $colName ?>"><?= strtoupper($colName) ?></label>
        <?php

        if (isset($dataType["REFERENCED_TABLE_NAME"])) {
            /** @var string|CRUD $relationClassName */
            $relationClassName = $dataType["CLASS_NAME"];
            ?>

            <select autocomplete="off" class="form-control" id="<?= $colName ?>" name="<?= $colName ?>">
                <?php
                $options = $relationClassName::getAll();

                /** @var CRUD $option */
                foreach ($options as $option) { ?>
                    <option value="<?= $option->id ?>"><?= $option->id . " => " . $option ?></option>
                <?php }
                ?>
            </select>
        <?php } else {
            preg_match('/^([a-zA-Z]+)(?:\(([^)]*)\))?$/', $dataType["COLUMN_TYPE"], $matches);

            switch ($matches[1]) {
                case 'int':
                case 'integer':
                    ?>
                    <input autocomplete="off" type="number" class="form-control" name="<?= $colName ?>"
                           value="<?= $value | "" ?>"
                           min="<?= -pow(2, 4 * 8 - 1) ?>"
                           max="<?= pow(2, 4 * 8 - 1) ?>" <?= $readOnly ? "readonly" : "" ?>/>
                    <?php
                    break;
                case 'boolean': ?>
                    <div class="form-check">
                        <input autocomplete="off" type="checkbox" class="form-check-input"
                               value="<?= $value | "" ?>" name="<?= $colName ?>" <?= $readOnly ? "readonly" : "" ?>>
                        <label class="form-check-label" for="<?= $colName ?>"><?= strtoupper($colName) ?></label>
                    </div>
                    <?php
                    break;
                case 'date': ?>
                    <input autocomplete="off" type="date" class="form-control" value="<?= $value | "" ?>"
                           name="<?= $colName ?>" <?= $readOnly ? "readonly" : "" ?>>
                    <?php
                    break;
                case 'varchar': ?>
                    <input autocomplete="off" type="text" class="form-control" name="<?= $colName ?>"
                           value="<?= $value | "" ?>"
                           maxlength="<?= $matches[2] ?>" <?= $readOnly ? "readonly" : "" ?>>
                    <?php
                    break;
                default: ?>
                    <input autocomplete="off" type="text" class="form-control" name="<?= $colName ?>"
                           value="<?= $value | "" ?>" <?= $readOnly ? "readonly" : "" ?>/>
                    <?php
                    break;
            }
        }
        ?>
    </div>
<?php }

function update(CRUD $item): void
{
    $dataTypes = $item::getDataType();
    $relations = $item::getReferences();
    $itemArray = (array)$item;
    ?>

    <div><a class="btn btn-primary" href="<?= $_SERVER["SCRIPT_NAME"] ?>?type=view_getAll&class=<?= $item::class ?>">Ver Todos</a></div>
    <form id="modifyForm" class="container mt-4">
        <?php foreach ($dataTypes as $dataType) : ?>
            <?php createInput($dataType, $dataType["COLUMN_KEY"] == "PRI", $itemArray[$dataType["COLUMN_NAME"]]); ?>
        <?php endforeach; ?>

        <?php if (sizeof($relations) > 0) : ?>
            <fieldset class="form-group">
                <?php foreach ($relations as $relation) : ?>
                    <?php /** @var string|CRUD $relationClassName */
                    $relationClassName = $relation["CLASS_NAME"];
                    $relationColumnName = $relation["REFERENCED_COLUMN_NAME"];
                    $filters = [$relation["COLUMN_NAME"] => $itemArray[$relationColumnName]];
                    ?>
                    <label class="font-weight-bold" for="<?= $relationClassName ?>">
                        <?= strtoupper($relationClassName) ?>
                    </label>
                    <ul>
                        <?php /** @var string|CRUD $column */ ?>
                        <?php foreach ($relationClassName::getAll($filters) as $column) : ?>
                            <li><?= $column ?> </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endforeach; ?>
            </fieldset>
        <?php endif; ?>

        <button type="button" class="btn btn-primary" onclick="submitChanges()">Enviar</button>
    </form>

    <script>
        const form = document.getElementById('modifyForm');
        const originalFormData = new FormData(form);

        function submitChanges() {

            const formData = new FormData();
            let data = {};
            const actualFormData = new FormData(form);

            actualFormData.forEach((value, key) => {
                if (originalFormData.get(key) !== value && !(originalFormData.get(key) === null && value === "")) {
                    data[key] = value;
                }
            })

            formData.append("type", "update")

            formData.append("filters", JSON.stringify({"id": <?= $item->id ?>}))

            formData.append("updates", JSON.stringify(data));

            formData.append("class", "<?= $item::class ?>")

            fetch("<?= $_SERVER["SCRIPT_NAME"] ?>", {
                method: 'POST',
                body: formData
            }).then(response => {
                if (!response.ok && !response.redirected) {
                    alert("No se ha podido actualizar")
                    return;
                }
                alert('Actualizado')
            });
        }
    </script>
<?php }

function insert(string|CRUD $className): void
{
    $dataTypes = $className::getDataType();
    ?>
    <div><a class="btn btn-primary" href="<?= $_SERVER["SCRIPT_NAME"] ?>?type=view_getAll&class=<?= $className ?>">Ver Todos</a></div>
    <form id="insertForm" class="container mt-4">
        <?php foreach ($dataTypes as $dataType) : ?>
            <?php if ($dataType["COLUMN_KEY"] == "PRI") {
                continue;
            } ?>
            <?php createInput($dataType, false, ""); // For insertion, all fields are writable ?>
        <?php endforeach; ?>

        <button type="button" class="btn btn-primary" onclick="submitInsert()">Insertar</button>
    </form>

    <script>
        function submitInsert() {

            const formData = new FormData();
            let data = {};
            const actualFormData = new FormData(document.getElementById('insertForm'));

            actualFormData.forEach((value, key) => {
                data[key] = value;
            })

            formData.append("values", JSON.stringify(data))
            formData.append("class", "<?= $className ?>")
            formData.append("type", "insert")
            fetch("<?= $_SERVER["SCRIPT_NAME"] ?>", {
                method: 'POST',
                body: formData
            }).then(response => {
                if (!response.ok && !response.redirected) {
                    alert("No se ha podido insertar el registro");
                    return;
                }
                alert('Registro insertado exitosamente');
            });
        }
    </script>
    <?php
}