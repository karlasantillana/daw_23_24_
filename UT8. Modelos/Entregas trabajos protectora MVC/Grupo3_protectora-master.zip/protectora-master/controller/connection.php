<?php
$DB_HOST = 'localhost';
$DB_NAME = 'protectora_animales';
$DB_USER = 'cabrasky';
$DB_PASS = 'javier149';
$pdo = new PDO('mysql:host=' . $DB_HOST . ';dbname=' . $DB_NAME, $DB_USER, $DB_PASS);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
