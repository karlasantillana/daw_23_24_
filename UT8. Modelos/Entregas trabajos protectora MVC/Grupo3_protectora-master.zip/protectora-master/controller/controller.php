<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

include '../model/CRUD.php';
include '../model/Animal.php';
include '../model/Adopcion.php';
include '../model/Usuario.php';
include '../view/View.php';
include '../view/Form.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
            crossorigin="anonymous"></script>
    <title>Protectora</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="<?= $_SERVER["SCRIPT_NAME"] ?>">Protectora</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <?php foreach (get_declared_classes() as $className) {
                    if (is_subclass_of($className, CRUD::class)) { ?>
                        <li class="nav-item">
                            <a class="nav-link"
                               href="<?= $_SERVER["SCRIPT_NAME"] ?>?type=view_getAll&class=<?= urlencode($className) ?>"><?=$className?></a>
                        </li>
                        <?php
                    }
                }
                ?>
            </ul>
        </div>
    </div>
</nav>


<?php

function view_get(string|CRUD $className, array $filters): void
{
    tableView($className, array($className::getUnique($filters)), $filters);
}

function view_getAll(string|CRUD $className, array $filters): void
{
    tableView($className, $className::getAll($filters), $filters);
}

function view_insert(string|CRUD $className): void
{
    insert($className);
}

function view_update(string|CRUD $className, array $filters): void
{
    update($className::getUnique($filters));
}

function back_insert(string|CRUD $className): void
{
    $className::insert(json_decode($_POST["values"], true));
    header("Location: {$_SERVER['SCRIPT_NAME']}?type=view_getAll&class=$className");
}

function back_update(string|CRUD $className, array $filters): void
{
    $className::getUnique($filters)->update(json_decode($_POST["updates"], true));
    header("Location: {$_SERVER['SCRIPT_NAME']}?type=view_getAll&class=$className");
}

function back_delete(string|CRUD $className, array $filters): void
{
    $className::getUnique($filters)->delete();
    header("Location: {$_SERVER['SCRIPT_NAME']}?type=view_getAll&class=$className");
}

if (!isset($_REQUEST["type"]) || !isset($_REQUEST['class'])) {
    ?>
    <div class="container mt-4">
        <h2>¡Bienvenido a la Protectora!</h2>
        <p>Para mirar ver todo usa el menú</p>
    </div>
    <?php
    die();
}
$filters = [];
if (isset($_REQUEST["filters"])) {
    $filters = (array)json_decode(urldecode($_REQUEST["filters"]));
}
switch ($_REQUEST["type"]) {
    case "view_get":
        view_get($_REQUEST["class"], $filters);
        break;
    case "view_getAll":
        view_getAll($_REQUEST["class"], $filters);
        break;
    case "view_update":
        view_update($_REQUEST["class"], $filters);
        break;
    case "view_insert":
        view_insert($_REQUEST["class"]);
        break;
    case "insert":
        back_insert($_REQUEST["class"]);
        break;
    case "update":
        back_update($_REQUEST["class"], $filters);
        break;
    case "delete":
        back_delete($_REQUEST["class"], $filters);
        break;


}
