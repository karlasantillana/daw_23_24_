<?php

namespace Models;

use Models\Connection;
use PDO;

include_once "Connection.php";
abstract class Crud extends Connection
{

    private $table;

    /**
     * @param $table
     */
    public function __construct($table)
    {
        $this->table = $table;
        parent::__construct();

    }


    public function obtieneTodos(){
        try {
            $sql = "SELECT * FROM $this->table";

            $sentence = $this->conn->prepare($sql);

            $sentence->execute();

            $result = $sentence->fetchAll(PDO::FETCH_OBJ);

        }catch(\Exception $exception){
            echo $exception->getMessage();
        }

        return $result;



    }

    public function obtieneDeId($id){
        try {
            $sql = "SELECT * FROM $this->table WHERE id = :id";

            $sentence = $this->conn->prepare($sql);
            $sentence->bindParam(':id', $id);

            $sentence->execute();

            $sentence->fetchAll(PDO::FETCH_OBJ);

        }catch(\Exception $exception){
            echo $exception->getMessage();
        }

        return $sentence;
    }

    public function borrar($id){
        try {
            $sql = "DELETE FROM $this->table WHERE id = :id";

            $sentence = $this->conn->prepare($sql);
            $sentence->bindParam(':id', $id);

            $sentence->execute();


        }catch(\Exception $exception){
            echo $exception->getMessage();
        }

    }


    public abstract function crear($data);

    public abstract function update($data);


}