<?php

namespace Models;

use Models\Crud;

include_once "Models/Crud.php";
class Usuario extends Crud
{

    private $id;

    private $nombre;

    private $apellido;

    private $sexo;

    private $direccion;

    private $telefono;

    private $edad;

    private const TABLE = "usuarios";

    private $conexion;

    /**
     * @param $id
     */
    public function __construct()
    {
        parent::__construct(self::TABLE);
        $this->conexion = $this->conn;
    }

    public function __get($name)
    {
        if(property_exists($name)){
            return $this->$name;
        }
    }

    public function __set($name, $value)
    {
        if(property_exists($name)){
            $this->$name = $value;
        }
    }


    public function crear($data)
    {
        try {
            $sql = "INSERT INTO usuarios VALUES (:id, :nombre, :apellido, :sexo, :direccion,:telefono)";
            $sentence = $this->conexion->prepare($sql);

            $sentence->bindParam(':id', $data['id']);
            $sentence->bindParam(':nombre', $data['nombre']);
            $sentence->bindParam(':apellido', $data['apellido']);
            $sentence->bindParam(':sexo', $data['sexo']);
            $sentence->bindParam(':direccion', $data['direccion']);
            $sentence->bindParam(':telefono', $data['telefono']);


            $sentence->execute();
        }catch (\Exception $exception){
            echo $exception->getMessage();
        }

    }

    public function update($data)
    {
        try {
            $sql = "UPDATE FROM usuarios SET nombre = :nombre, apellido = :apellido, sexo = :sexo, direccion = :direccion, telefono = :telefono WHERE id = :id";
            $sentence = $this->conexion->prepare($sql);

            $sentence->bindParam(':nombre', $data['nombre']);
            $sentence->bindParam(':apellido', $data['apellido']);
            $sentence->bindParam(':sexo', $data['sexo']);
            $sentence->bindParam(':direccion', $data['direccion']);
            $sentence->bindParam(':telefono', $data['telefono']);
            $sentence->bindParam(':id', $data['id']);



            $sentence->execute();

        }catch (\Exception $exception){
            echo $exception->getMessage();
            echo $exception->getLine();
        } finally {
            echo "Holiii";
        }
    }


}


?>