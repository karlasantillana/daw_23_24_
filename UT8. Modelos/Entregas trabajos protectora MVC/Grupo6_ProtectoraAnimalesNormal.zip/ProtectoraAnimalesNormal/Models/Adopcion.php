<?php

namespace Models;
use Models\Crud;

include_once "Models/Crud.php";

class Adopcion extends Crud
{
    private $id;

    private $idAnimal;

    private $idUsuario;

    private $fecha;

    private $razon;

    private const TABLE = "adopcion";

    private $conexion;

    /**
     * @param $id
     */
    public function __construct()
    {
        parent::__construct(self::TABLE);
        $this->conexion = $this->conn;
    }

    public function __get($name)
    {
        if(property_exists($name)){
            return $this->$name;
        }
    }

    public function __set($name, $value)
    {
        if(property_exists($name)){
            $this->$name = $value;
        }
    }


    public function crear($data)
    {
        try {
            $sql = "INSERT INTO adopcion VALUES (:id, :idAnimal, :idUsuario, :fecha, :razon)";
            $sentence = $this->conexion->prepare($sql);

            $sentence->bindParam(':id', $data['id']);
            $sentence->bindParam(':idAnimal', $data['idAnimal']);
            $sentence->bindParam(':idUsuario', $data['idUsuario']);
            $sentence->bindParam(':fecha', $data['fecha']);
            $sentence->bindParam(':razon', $data['razon']);


            $sentence->execute();
        }catch (\Exception $exception){
            echo $exception->getMessage();
        }

    }

    public function update($data)
    {
        try {
            $sql = "UPDATE FROM adopcion SET idAnimal = :idAnimal, idUsuario = :idUsuario, fecha = :fecha, razon = :razon WHERE id = :id";
            $sentence = $this->conexion->prepare($sql);

            $sentence->bindParam(':idAnimal', $data['idAnimal']);
            $sentence->bindParam(':idUsuario', $data['idUsuario']);
            $sentence->bindParam(':fecha', $data['fecha']);
            $sentence->bindParam(':razon', $data['razon']);
            $sentence->bindParam(':id', $data['id']);



            $sentence->execute();
        }catch (\Exception $exception){
            echo $exception->getMessage();
        }
    }
}