<?php

namespace Models;

use PDO;
use PDOException;

class Connection
{
    private $server = "localhost:3306";
    protected $username;
    private $password;
    private $database;
    protected $conn;


    public function __construct($username = "root", $password = "", $database= "pufosa"){
        $this->inizialiateVariables();
    }

    private function inizialiateVariables(): void
    {
        $file = 'config.properties';

            $properties = parse_ini_file($file);
            if($properties !== false){
                $this->server = $properties['MYSQL_SERVER'] ?? $properties['MYSQL_IP'] . "" . $properties['MYSQL_PORT'];
                $this->username = $properties['MYSQL_USERNAME'];
                $this->password = $properties['MYSQL_PASSWORD'];
                $this->database = $properties['MYSQL_DATABASE'];
            }



        try{
            $this->conn = new PDO("mysql:host=" . $this->server . "; dbname=$this->database; charset=utf8", $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        }catch(PDOException $e){
            echo "". $e->getMessage();
        }
    }





}