<?php

namespace Models;

use Models\Crud;

include_once "Models/Crud.php";
class Animal extends Crud
{
    private $id;

    private $nombre;

    private $especie;

    private $raza;

    private $genero;

    private $color;

    private $edad;

    private const TABLE = "animal";

    private $conexion;

    /**
     * @param $id
     */
    public function __construct()
    {
        parent::__construct(self::TABLE);
        $this->conexion = $this->conn;
    }

    public function __get($name)
    {
        if(property_exists($name)){
            return $this->$name;
        }
    }

    public function __set($name, $value)
    {
        if(property_exists($name)){
            $this->$name = $value;
        }
    }


    public function crear($data)
    {
        try {
            $sql = "INSERT INTO animal VALUES (:id, :nombre, :especie, :raza, :genero,:color, :edad)";
            $sentence = $this->conexion->prepare($sql);

            $sentence->bindParam(':id', $data['id']);
            $sentence->bindParam(':nombre', $data['nombre']);
            $sentence->bindParam(':especie', $data['especie']);
            $sentence->bindParam(':raza', $data['raza']);
            $sentence->bindParam(':genero', $data['genero']);
            $sentence->bindParam(':color', $data['color']);
            $sentence->bindParam(':edad', $data['edad']);


            $sentence->execute();
        } catch (\Exception $exception){
            echo $exception->getMessage();
        }

    }

    public function update($data)
    {
        try {
            $sql = "UPDATE FROM animal SET nombre = :nombre, especie = :especie, raza = :raza, genero = :genero, color = :color, edad = :edad WHERE id = :id";
            $sentence = $this->conexion->prepare($sql);

            $sentence->bindParam(':nombre', $data['nombre']);
            $sentence->bindParam(':especie', $data['especie']);
            $sentence->bindParam(':raza', $data['raza']);
            $sentence->bindParam(':genero', $data['genero']);
            $sentence->bindParam(':color', $data['color']);
            $sentence->bindParam(':edad', $data['edad']);

            $sentence->bindParam(':id', $data['id']);



            $sentence->execute();
        } catch (\Exception $exception) {
            echo $exception->getMessage();
        }
    }
}