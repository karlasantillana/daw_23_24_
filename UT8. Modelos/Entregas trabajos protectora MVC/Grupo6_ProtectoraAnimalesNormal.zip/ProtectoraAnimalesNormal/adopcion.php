<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Protectora animales</title>
</head>
<body>


<a href="animal.php">Animal</a>
<a href="usuarios.php">Usuarios</a>
<a href="adopcion.php">Adopcion</a>


<table>
    <tr>
        <td>ID</td>
        <td>idAnimal</td>
        <td>idUsuario</td>
        <td>fecha</td>
        <td>razon</td>

        <td></td>
        <td></td>

    </tr>



    <?php

    use Controllers\DynamicController;



    include_once "Controllers/DynamicControllePrueba.php";
    $adopcion = new Adopcion();


    foreach ($adopcion->obtieneTodos() as $value){
        echo "<tr>";

        echo "<form action='' method='post'>";
        echo "<td><input name='id' value='$value->id'></td>";
        echo "<td><input name='idAnimal' value='$value->idAnimal'></td>";
        echo "<td><input name='idUsuario' value='$value->idUsuario'></td>";
        echo "<td><input name='fecha' value='$value->fecha'></td>";
        echo "<td><input name='razon' value='$value->razon'></td>";
        echo "<td><input name='btnActualizar' type='submit' value='Actualizar'></td>";

        echo "<td><input name='btnBorrar' type='submit' value='Borrar'></td>";
        echo "</form>";
        echo "</tr>";
    }


    if(isset($_POST['btnBorrar'])){
        echo "Le has dado a borrar";
        DynamicControllePrueba::deleteByTable('adopcion', $_POST['id']);
    }

    if(isset($_POST['btnActualizar'])){
        echo "Le has dado a actualizar";

        DynamicControllePrueba::updateByTable('adopcion', $_POST);
    }





    ?>
</table>

<table>
    <tr>
        <td>ID</td>
        <td>idAnimal</td>
        <td>idUsuario</td>
        <td>fecha</td>
        <td>razon</td>

    </tr>

    <tr>
        <form action="adopcion.php" method="post">
            <td><input type="text" name="id"></td>
            <td><input type="text" name="idAnimal"></td>
            <td><input type="text" name="idUsuario"></td>
            <td><input type="text" name="fecha"></td>
            <td><input type="text" name="razon"></td>
            <td><input name="btnCrear" type="submit" value="Añadir"> </td>
        </form>

    </tr>
</table>

<?php

if(isset($_POST['btnCrear'])){
    echo "Le has dado a crear";

    DynamicControllePrueba::crear('adopcion', $_POST);
}
?>

</body>
</html>