<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Protectora animales</title>
</head>
<body>


<a href="animal.php">Animal</a>
<a href="usuarios.php">Usuarios</a>
<a href="adopcion.php">Adopcion</a>


<table>
    <tr>
        <td>ID</td>
        <td>Nombre</td>
        <td>Especie</td>
        <td>Raza</td>
        <td>Genero</td>
        <td>Color</td>
        <td>Edad</td>


        <td></td>
        <td></td>

    </tr>



    <?php

    use Controllers\DynamicController;



    include_once "Controllers/DynamicControllePrueba.php";
    $adopcion = new Animal();


    foreach ($adopcion->obtieneTodos() as $value){
        echo "<tr>";

        echo "<form action='' method='post'>";
        echo "<td><input name='id' value='$value->id'></td>";
        echo "<td><input name='nombre' value='$value->nombre'></td>";
        echo "<td><input name='especie' value='$value->especie'></td>";
        echo "<td><input name='raza' value='$value->raza'></td>";
        echo "<td><input name='genero' value='$value->genero'></td>";
        echo "<td><input name='color' value='$value->color'></td>";
        echo "<td><input name='edad' value='$value->edad'></td>";

        echo "<td><input name='btnActualizar' type='submit' value='Actualizar'></td>";

        echo "<td><input name='btnBorrar' type='submit' value='Borrar'></td>";
        echo "</form>";
        echo "</tr>";
    }


    if(isset($_POST['btnBorrar'])){
        echo "Le has dado a borrar";
        DynamicControllePrueba::deleteByTable('animal', $_POST['id']);
    }

    if(isset($_POST['btnActualizar'])){
        echo "Le has dado a actualizar";

        DynamicControllePrueba::updateByTable('animal', $_POST);
    }





    ?>
</table>

<table>
    <tr>
        <td>ID</td>
        <td>Nombre</td>
        <td>Especie</td>
        <td>Raza</td>
        <td>Genero</td>
        <td>Color</td>
        <td>Edad</td>

    </tr>

    <tr>
        <form action="animal.php" method="post">
            <td><input type="text" name="id"></td>
            <td><input type="text" name="nombre"></td>
            <td><input type="text" name="especie"></td>
            <td><input type="text" name="raza"></td>
            <td><input type="text" name="genero"></td>
            <td><input type="text" name="color"></td>
            <td><input type="text" name="edad"></td>
            <td><input name="btnCrear" type="submit" value="Añadir"> </td>
        </form>

    </tr>
</table>

<?php

if(isset($_POST['btnCrear'])){
    echo "Le has dado a crear";

    DynamicControllePrueba::crear('animal', $_POST);
}
?>

</body>
</html>