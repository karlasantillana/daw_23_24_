<?php

namespace Controllers;




require_once "Models/Adopcion.php";
require_once "Models/Animal.php";
require_once "Models/Usuario.php";


use Models\Crud;
use Models\Usuario;

include_once "Models/Crud.php";

class DynamicController
{
    public static function deleteByTable($table, $id){

        $nombreTabla = ucfirst($table);
        $model = new $nombreTabla;
        $model->borrar($id);
    }


    public static function updateByTable($table){
        $nombreTabla = ucfirst($table);

        $model = new $nombreTabla;

        if(isset($_POST['id'])){
            $data = [];
            if($table == "adopcion"){
                $data = [
                    'id' =>  $_POST['id'],
                    'idAnimal' => $_POST['idAnimal'],
                    'idUsuario' => $_POST['idUsuario'],
                    'fecha' => $_POST['fecha'],
                    'razon' =>  $_POST['razon']
                ];
            } else if($table == "animal"){

                $data = [
                  'id' => $_POST['id'],
                  'nombre' =>$_POST['nombre'],
                  'especie' =>$_POST['especie'],
                  'raza' =>$_POST['raza'],
                  'genero' =>$_POST['genero'],
                  'color'=>$_POST['color'],
                  'edad' =>$_POST['edad']
                ];

            }else if($table == "usuarios"){

                $data = [
                  'id' => $_POST['id'],
                  'nombre' => $_POST['nombre'],
                  'apellido' => $_POST['apellido'],
                  'sexo' => $_POST['sexo'],
                  'direccion' => $_POST['direccion'],
                  'telefono' => $_POST['telefono']
                ];
            }
        }
        $model->udpate($data);
    }


    public static function crear($table){
        $nombreTabla = ucfirst($table);

        var_dump($nombreTabla);
        $model = new $nombreTabla;


        if(isset($_POST['id'])){

            $data = [];
            if($table == "adopcion"){
                $data = [
                    'id' =>  $_POST['id'],
                    'idAnimal' => $_POST['idAnimal'],
                    'idUsuario' => $_POST['idUsuario'],
                    'fecha' => $_POST['fecha'],
                    'razon' =>  $_POST['razon']
                ];
            } else if($table == "animal"){

                $data = [
                    'id' => $_POST['id'],
                    'nombre' =>$_POST['nombre'],
                    'especie' =>$_POST['especie'],
                    'raza' =>$_POST['raza'],
                    'genero' =>$_POST['genero'],
                    'color'=>$_POST['color'],
                    'edad' =>$_POST['edad']
                ];

            }else if($table == "usuarios"){
                echo $_POST['nombre'];
                $data = [
                    'id' => $_POST['id'],
                    'nombre' => $_POST['nombre'],
                    'apellido' => $_POST['apellido'],
                    'sexo' => $_POST['sexo'],
                    'direccion' => $_POST['direccion'],
                    'telefono' => $_POST['telefono']
                ];
            }
        }
        $model->crear($data);
    }
}



