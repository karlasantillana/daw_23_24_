<?php

class Connection
{
    private $server = "localhost:3306";
    protected $username;
    private $password;
    private $database;
    protected $conn;


    public function __construct($username = "root", $password = "", $database= "pufosa"){
        $this->inizialiateVariables();
    }

    private function inizialiateVariables(): void
    {
        $file = 'config.properties';


            $this->server = "localhost:3306";
            $this->username = "root";
            $this->password = "";
            $this->database = "protectora_animales";




        try{
            $this->conn = new PDO("mysql:host=" . $this->server . "; dbname=$this->database; charset=utf8", $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        }catch(PDOException $e){
            echo "". $e->getMessage();
        }
    }





}

abstract class Crud extends Connection
{

    private $table;

    /**
     * @param $table
     */
    public function __construct($table)
    {
        $this->table = $table;
        parent::__construct();

    }


    public function obtieneTodos(){
        $result = null;
        try {
            $sql = "SELECT * FROM $this->table";

            $sentence = $this->conn->prepare($sql);

            $sentence->execute();

            $result = $sentence->fetchAll(PDO::FETCH_OBJ);

        }catch(\Exception $exception){
            echo $exception->getMessage();
        }

        return $result;



    }

    public function obtieneDeId($id){
        try {
            $sql = "SELECT * FROM $this->table WHERE id = :id";

            $sentence = $this->conn->prepare($sql);
            $sentence->bindParam(':id', $id);

            $sentence->execute();

            $sentence->fetchAll(PDO::FETCH_OBJ);

        }catch(\Exception $exception){
            echo $exception->getMessage();
        }

        return $sentence;
    }

    public function borrar($id){
        try {
            $sql = "DELETE FROM $this->table WHERE id = :id";

            $sentence = $this->conn->prepare($sql);
            $sentence->bindParam(':id', $id);

            $sentence->execute();


        }catch(\Exception $exception){
            echo $exception->getMessage();
        }

    }


    public abstract function crear($data);

    public abstract function update($data);


}

class Animal extends Crud
{
    private $id;

    private $nombre;

    private $especie;

    private $raza;

    private $genero;

    private $color;

    private $edad;

    private const TABLE = "animal";

    private $conexion;

    /**
     * @param $id
     */
    public function __construct()
    {
        parent::__construct(self::TABLE);
        $this->conexion = $this->conn;
    }

    public function __get($name)
    {
        if(property_exists($name)){
            return $this->$name;
        }
    }

    public function __set($name, $value)
    {
        if(property_exists($name)){
            $this->$name = $value;
        }
    }


    public function crear($data)
    {
        try {
            $sql = "INSERT INTO animal VALUES (:id, :nombre, :especie, :raza, :genero,:color, :edad)";
            $sentence = $this->conexion->prepare($sql);

            $sentence->bindParam(':id', $data['id']);
            $sentence->bindParam(':nombre', $data['nombre']);
            $sentence->bindParam(':especie', $data['especie']);
            $sentence->bindParam(':raza', $data['raza']);
            $sentence->bindParam(':genero', $data['genero']);
            $sentence->bindParam(':color', $data['color']);
            $sentence->bindParam(':edad', $data['edad']);


            $sentence->execute();
        } catch (\Exception $exception){
            echo $exception->getMessage();
        }

    }

    public function update($data)
    {
        try {
            $sql = "UPDATE animal SET nombre = :nombre, especie = :especie, raza = :raza, genero = :genero, color = :color, edad = :edad WHERE id = :id";
            $sentence = $this->conexion->prepare($sql);

            $sentence->bindParam(':nombre', $data['nombre']);
            $sentence->bindParam(':especie', $data['especie']);
            $sentence->bindParam(':raza', $data['raza']);
            $sentence->bindParam(':genero', $data['genero']);
            $sentence->bindParam(':color', $data['color']);
            $sentence->bindParam(':edad', $data['edad']);

            $sentence->bindParam(':id', $data['id']);



            $sentence->execute();
        } catch (\Exception $exception) {
            echo $exception->getMessage();
        }
    }
}
class Adopcion extends Crud
{
    private $id;

    private $idAnimal;

    private $idUsuario;

    private $fecha;

    private $razon;

    private const TABLE = "adopcion";

    private $conexion;

    /**
     * @param $id
     */
    public function __construct()
    {
        parent::__construct(self::TABLE);
        $this->conexion = $this->conn;
    }

    public function __get($name)
    {
        if(property_exists($name)){
            return $this->$name;
        }
    }

    public function __set($name, $value)
    {
        if(property_exists($name)){
            $this->$name = $value;
        }
    }


    public function crear($data)
    {
        try {
            $sql = "INSERT INTO adopcion VALUES (:id, :idAnimal, :idUsuario, :fecha, :razon)";
            $sentence = $this->conexion->prepare($sql);

            $sentence->bindParam(':id', $data['id']);
            $sentence->bindParam(':idAnimal', $data['idAnimal']);
            $sentence->bindParam(':idUsuario', $data['idUsuario']);
            $sentence->bindParam(':fecha', $data['fecha']);
            $sentence->bindParam(':razon', $data['razon']);


            $sentence->execute();
        }catch (\Exception $exception){
            echo $exception->getMessage();
        }

    }

    public function update($data)
    {
        try {
            $sql = "UPDATE FROM adopcion SET idAnimal = :idAnimal, idUsuario = :idUsuario, fecha = :fecha, razon = :razon WHERE id = :id";
            $sentence = $this->conexion->prepare($sql);

            $sentence->bindParam(':idAnimal', $data['idAnimal']);
            $sentence->bindParam(':idUsuario', $data['idUsuario']);
            $sentence->bindParam(':fecha', $data['fecha']);
            $sentence->bindParam(':razon', $data['razon']);
            $sentence->bindParam(':id', $data['id']);



            $sentence->execute();
        }catch (\Exception $exception){
            echo $exception->getMessage();
        }
    }
}
class Usuario extends Crud
{

    private $id;

    private $nombre;

    private $apellido;

    private $sexo;

    private $direccion;

    private $telefono;

    private $edad;

    private const TABLE = "usuarios";

    private $conexion;

    /**
     * @param $id
     */
    public function __construct()
    {
        parent::__construct(self::TABLE);
        $this->conexion = $this->conn;
    }

    public function __get($name)
    {
        if(property_exists($name)){
            return $this->$name;
        }
    }

    public function __set($name, $value)
    {
        if(property_exists($name)){
            $this->$name = $value;
        }
    }


    public function crear($data)
    {
        try {
            $sql = "INSERT INTO usuarios VALUES (:id, :nombre, :apellido, :sexo, :direccion,:telefono)";
            $sentence = $this->conexion->prepare($sql);

            $sentence->bindParam(':id', $data['id']);
            $sentence->bindParam(':nombre', $data['nombre']);
            $sentence->bindParam(':apellido', $data['apellido']);
            $sentence->bindParam(':sexo', $data['sexo']);
            $sentence->bindParam(':direccion', $data['direccion']);
            $sentence->bindParam(':telefono', $data['telefono']);


            $sentence->execute();
        }catch (\Exception $exception){
            echo $exception->getMessage();
        }

    }

    public function update($data)
    {
        try {
            $sql = "UPDATE usuarios SET nombre = :nombre, apellido = :apellido, sexo = :sexo, direccion = :direccion, telefono = :telefono WHERE id = :id";
            $sentence = $this->conexion->prepare($sql);

            $sentence->bindParam(':nombre', $data['nombre']);
            $sentence->bindParam(':apellido', $data['apellido']);
            $sentence->bindParam(':sexo', $data['sexo']);
            $sentence->bindParam(':direccion', $data['direccion']);
            $sentence->bindParam(':telefono', $data['telefono']);
            $sentence->bindParam(':id', $data['id']);



            $sentence->execute();

        }catch (\Exception $exception){
            echo $exception->getMessage();

        } finally {
        }
    }


}

class DynamicControllePrueba
{
    public static function deleteByTable($table, $id){

        $nombreTabla = ucfirst($table);
        $model = new $nombreTabla;
        $model->borrar($id);
    }


    public static function updateByTable($table, $datos){
        $nombreTabla = ucfirst($table);

        $model = new $nombreTabla;

        if(isset($datos['id'])){
            $data = [];
            if($table == "adopcion"){
                $data = [
                    'id' =>  $datos['id'],
                    'idAnimal' => $datos['idAnimal'],
                    'idUsuario' => $datos['idUsuario'],
                    'fecha' => $datos['fecha'],
                    'razon' =>  $datos['razon']
                ];
            } else if($table == "animal"){

                $data = [
                  'id' => $datos['id'],
                  'nombre' =>$datos['nombre'],
                  'especie' =>$datos['especie'],
                  'raza' =>$datos['raza'],
                  'genero' =>$datos['genero'],
                  'color'=>$datos['color'],
                  'edad' =>$datos['edad']
                ];

            }else if($table == "usuario"){
                $data = [
                  'id' => $datos['id'],
                  'nombre' => $datos['nombre'],
                  'apellido' => $datos['apellido'],
                  'sexo' => $datos['sexo'],
                  'direccion' => $datos['direccion'],
                  'telefono' => $datos['telefono']
                ];
            }

            $model->update($data);

        }

    }


    public static function crear($table, $datos){
        $nombreTabla = ucfirst($table);

        var_dump($nombreTabla);
        $model = new $nombreTabla;


        if(isset($datos['id'])){

            $data = [];
            if($table == "adopcion"){
                $data = [
                    'id' =>  $datos['id'],
                    'idAnimal' => $datos['idAnimal'],
                    'idUsuario' => $datos['idUsuario'],
                    'fecha' => $datos['fecha'],
                    'razon' =>  $datos['razon']
                ];
            } else if($table == "animal"){

                $data = [
                    'id' => $datos['id'],
                    'nombre' =>$datos['nombre'],
                    'especie' =>$datos['especie'],
                    'raza' =>$datos['raza'],
                    'genero' =>$datos['genero'],
                    'color'=>$datos['color'],
                    'edad' =>$datos['edad']
                ];

            }else if($table == "usuario"){

                $data = [
                    'id' => $datos['id'],
                    'nombre' => $datos['nombre'],
                    'apellido' => $datos['apellido'],
                    'sexo' => $datos['sexo'],
                    'direccion' => $datos['direccion'],
                    'telefono' => $datos['telefono']
                ];
            }
        }
        $model->crear($data);
    }
}



