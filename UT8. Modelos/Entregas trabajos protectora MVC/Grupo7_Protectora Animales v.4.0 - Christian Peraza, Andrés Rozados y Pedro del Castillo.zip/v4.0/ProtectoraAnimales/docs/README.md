# Protectora de Animales
Implementación de la arquitectura/patrón Modelo-Vista-Controlador en el trabajo de la Protectora de Animales.

## Versión 4.0 (17/12/2023)
Terminada interfaz gráfica al completo. Funcionalidades están correctamente terminadas. Falta gestión de errores, no se puede hacer bien sin includes. 

## Versión 3.5 (15/12/2023)
Terminada funcionalidad completa de la aplicación. No hay interfaz gráfica todavía y faltan probar las casuisticas para la gestión de errores.  

## Versión 3.4 (14/12/2023)
Funciones de crear y actualizar automatizadas. Testear y comprobar errores en el resto de la aplicación.

## Versión 3.3 (13/12/2023)
Trabajo trasladado de Drive a GitHub. 

## Versión 3.1 (10/12/2023)
Añadida la funcionalidad de crear un nuevo animal. Al crearlo se pueden comprobar si se ha introducido correctamente y mostrar los demás animales en la propia vista de "Animal". 

Creada la carpeta "docs" para documentar el seguimiento de versiones y mejoras para la propia aplicación. 

## Versión 3.0 (9/12/2023)
Enunciado base hecho y usamos como estructura para empezar el trabajo el código de Christian.