<?php

// Constantes con los parámetros requeridos para la conexión con la BBDD.
const SERVERNAME = "localhost:3306";
const DVNAME = "protectora_animales";
const USERNANME = "root";
const PASSWORD = "";
const CHARSET = "UTF8MB4";

?>