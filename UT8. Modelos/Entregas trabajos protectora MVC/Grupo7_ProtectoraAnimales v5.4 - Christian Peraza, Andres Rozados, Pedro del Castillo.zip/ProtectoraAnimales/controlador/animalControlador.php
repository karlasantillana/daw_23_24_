<?php

//Incluyendo la vista de la tabla y la clase de modelo que se va a usar
include_once '../modelo/Animal.php';
include_once '../vista/MontadorTablas.php';

class ControladorAnimal
{
    // Creador de tabla html para todas las clases
    public static function generarTabla()
    {
        $tablaGenerar = new TablaObjeto(new Animal());
        echo $tablaGenerar -> imprimirTabla();
    }

    // Importa la vista para introducir adopcion 
    public static function introducirAnimal()
    {
        include_once '../vista/animal/introducirAnimal.php';
        
        $interfazIntroducirAnimal = new IntroducirVistaAnimal();
        
        // Te muestra la vista de introducir usuario
        $interfazIntroducirAnimal -> imprimir();
    }

    // Crear una nuevo animal en la bbdd
    public static function insertarAnimal()
    {
        try 
        {
            // Si en el formulario hay parámetros vacíos
            if ($_POST["nombre"] === "" || $_POST["especie"] === "" || $_POST["raza"] === "" || $_POST["genero"] === "" || $_POST["color"] === "" || $_POST["edad"] === "") 
            {
                throw new Exception("No puede haber nada vacío.", 1);
            }

            // Se crea el objeto y se llama a la función correspondiente para crear
            $crudAnimal = new Crud('animal');
           
            $crudAnimal -> crear();

            // Si no se lanza ningún error imprime el mensaje de introducción correctamente hecha
            echo '<p class="mensaje-de-operacion-aceptada"">Animal introducido correctamente.</p>';

        } 

            catch (Exception $e) 
            {
                echo '<p class="mensaje-de-error-operacion"">'.$e -> getMessage().'</p>';
            }
    }

    // Muestra el formulario para actualizar el Animal
    public static function mostrarVistaActualizarAnimal()
    {
        // Actualizar fila
        try 
        {
            $animal = new Animal();
            
            // ActualizarFila contiene el id del animal a modificar
            $animal = $animal -> obtieneDeId($_POST['actualizaFila'])[0]; //devuelve el objeto de tipo stdClass 

            // Se importa la clase necesaria para luego imprimir el formulario par actualizar los usuarios
            include_once '../vista/animal/actualizarFilaAnimal.php';
            
            $formularioActualizar = new ActualizarVistaAnimal($animal);
            
            $formularioActualizar -> imprimir();
        } 
        
            catch (Exception $e) 
            {
                echo $e;
            }
    }

    // Contiene la lógica para actualizar en la BBDD del Animal recibida por POST
    public static function actualizarAnimal()
    {
        // Creando objeto de tipo Adopcion el cual contiene la funcion actualizar proviniente del Crud
        $actualizarAnimal = new Animal($_POST['nombre'], $_POST['especie'], $_POST['raza'], $_POST['genero'], $_POST['color'], $_POST['edad']);

        // Realizando la actualizacion
        $actualizarAnimal -> actualizar();
    }

    // Borra el Animal de la fila correspondiente
    public static function borrarFila()
    {
        // Se requiere de la creacion de un objeto Animal para usar el metodo borrar
        $animal = new Animal('', "", "", "", "", "", "");
        
        try 
        {
            // BorrarFila corresponde al id de Animal
            $animal -> borrar($_POST['borrarFila']);
        } 
        
            catch (Exception $e) 
            {
                echo $e;
            }
    }
}

// Llamadas a las funciones cuando se pulsan los botones correspondientes
if (isset($_POST['reclamoTabla'])) 
{
    ControladorAnimal::generarTabla();
}

if (isset($_POST['botonIntroducirPulsado'])) 
{
    ControladorAnimal::introducirAnimal();
}

if (isset($_POST['botonInsertarPulsado'])) 
{
    ControladorAnimal::insertarAnimal();
}

if (isset($_POST['actualizaFila'])) 
{
    ControladorAnimal::mostrarVistaActualizarAnimal();
}

if (isset($_POST['id'])) 
{
    ControladorAnimal::actualizarAnimal();
}

if (isset($_POST['borrarFila'])) 
{
    ControladorAnimal::borrarFila();
}