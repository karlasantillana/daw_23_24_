<?php

// Incluyendo la vista de la tabla y la clase de modelo que se va a usar
include_once '../modelo/Usuario.php';
include_once '../vista/MontadorTablas.php';

class ControladorUsuario
{
    // Creador de tabla html para todas las clases (Adopcion,Animal,Usuario)
    public static function generarTabla()
    {
        $tablaGenerar = new TablaObjeto(new Usuario()); // Se manda a la vista que pide la tabla usuario
        echo $tablaGenerar -> imprimirTabla();
    }

    // Importa la vista para introducir adopcion 
    public static function introducirUsuario()
    {
        include_once '../vista/usuario/introducirUsuario.php';
        
        $interfazIntroducirUsuario = new IntroducirVistaUsuario();
        $interfazIntroducirUsuario -> imprimir();
    }

    // Crear una nuevo usuario en la bbdd
    public static function insertarUsuario()
    {
        try 
        {
            // Si en el formulario hay parámetros vacíos
            if ($_POST["nombre"] === "" || $_POST["apellido"] === "" || $_POST["sexo"] === "" || $_POST["direccion"] === "" || $_POST["telefono"] === "") 
            {
                throw new Exception("No puede haber nada vacío.", 1);
            }

            // Se crea el objeto y se llama a la función correspondiente para crear
            $crudUsuario = new Crud('usuarios');
            $crudUsuario -> crear();

            // Si no se lanza ningún error imprime el mensaje de introducción Correctamente hecha
            echo '<p class="mensaje-de-operacion-aceptada"">Usuario introducido correctamente.</p>';
        } 
        
            catch (Exception $e) 
            {
                echo '<p class="mensaje-de-error-operacion"">'.$e -> getMessage().'</p>';
            }
    }

    // Muestra el formulario para actualizar el usuario
    public static function mostrarVistaActualizarUsuario()
    {
        try 
        {
            $usuario = new Usuario();
            
            // ActualizarFila contiene el id del usuario a modificar
            $usuario = $usuario -> obtieneDeId($_POST['actualizaFila'])[0]; // Devuelve el objeto de tipo stdClass 

            // Se importa la clase necesaria para luego imprimir el formulario par actualizar los usuarios
            include_once '../vista/usuario/actualizarFilaUsuario.php';
            
            $formularioActualizar = new ActualizarVistaUsuario($usuario);
            $formularioActualizar -> imprimir();
        } 
        
            catch (Exception $e) 
            {
                echo $e;
            }
    }

    // Contiene la lógica para actualizar en la BBDD del Usuario recibida por POST
    public static function actualizarUsuario()
    {
        // Creando objeto de tipo Adopcion el cual contiene la funcion actualizar proviniente del Crud
        $interfazActualizarUsuario = new Usuario($_POST['id'], $_POST['nombre'], $_POST['apellido'], $_POST['sexo'], $_POST['direccion'], $_POST['telefono']);
        
        // Realizando la actualizacion
        $interfazActualizarUsuario -> actualizar();
    }

    public static function borrarFila()
    {
        // Se requiere de la creacion de un objeto Usuario para usar el metodo borrar
        $usuario = new Usuario('', "", "", "", "", "");
        
        try 
        {
            // BorrarFila corresponde al id de Usuario
            $usuario -> borrar($_POST['borrarFila']);
        } 
        
            catch (Exception $e) 
            {
                echo $e;
            }
    }
}

// Llamadas a las funciones cuando se pulsan los botones correspondientes
if (isset($_POST['reclamoTabla'])) 
{
    ControladorUsuario::generarTabla();
}

if (isset($_POST['botonIntroducirPulsado'])) 
{
    ControladorUsuario::introducirUsuario();
}

if (isset($_POST['botonInsertarPulsado'])) 
{
    ControladorUsuario::insertarUsuario();
}

if (isset($_POST['actualizaFila'])) 
{
    ControladorUsuario::mostrarVistaActualizarUsuario();
}

if (isset($_POST['id'])) 
{
    ControladorUsuario::actualizarUsuario();
}

if (isset($_POST['borrarFila'])) 
{
    ControladorUsuario::borrarFila();
}
