<?php
// Al prinicpio simpre se añade la cabecera con los botones
include_once '../vista/cabecera.php';

// Incluyendo todas las dependencias necesarias para orquestar los 3 controladores
include_once '../vista/MontadorTablas.php'; // Importamos la clase tabla para mostrar la tabla
include_once '../modelo/Usuario.php';
include_once '../modelo/Animal.php';
include_once '../modelo/Adopcion.php';

// Variable usada para imprimir la tabla donde se muestran todos los registros o de usuario o animal o adopcion
$tablaGenerar="";

// Variable usada para realizar el include de los controladores usuario o animal o adopcion
$importarControlador="";


// Primero revisa si le llega algun parámetro botonPulsado, que ocurre cuando se pulsa algun boton del index o del header
// Ademas no recibe llega el nombreTabla ya que este solo se genera cuando se intenta mostrar algun valor de la tabla
if (isset($_POST['botonPulsado']) && !isset($_POST['nombreTabla']))
{
    
    if ($_POST['botonPulsado']==="Usuario")
    {
        $tablaGenerar = new TablaObjeto(new Usuario()); 
    }
    
        else if ($_POST['botonPulsado'] === "Animal") 
        {
            $tablaGenerar = new TablaObjeto(new Animal());
        } 
        
            else if ($_POST['botonPulsado'] === "Adopcion") 
            {
                $tablaGenerar = new TablaObjeto(new Adopcion());
            }

    $tablaGenerar -> imprimirTabla();
}

// Cuando se pulsa algun botón de la tabla o para introducir ulguna entidad (usuario o animal o adopcion)
if (isset($_POST['nombreTabla'])) 
{ 
    if ($_POST['nombreTabla'] === "Usuario")
    {
        // Creado objeto para generar la tabla y eligiendo que controlador se importa
        $tablaGenerar = new TablaObjeto(new Usuario());
        $importarControlador = 'usuarioControlador.php';
    }
        else if ($_POST['nombreTabla']==="Adopcion")
        {
            // Creado objeto para generar la tabla y eligiendo que controlador se importa
            $tablaGenerar = new TablaObjeto(new Adopcion());
            $importarControlador = 'adopcionControlador.php';
        }
            else if ($_POST['nombreTabla']==="Animal")
            {
                // Creado objeto para generar la tabla y eligiendo que controlador se importa
                $tablaGenerar = new TablaObjeto(new Animal());
                $importarControlador = 'animalControlador.php';
            }

    //Se importa el controlador elegido en el if
    include_once $importarControlador;

    //Se imprime la tabla por pantalla
    $tablaGenerar -> imprimirTabla();
}

?>