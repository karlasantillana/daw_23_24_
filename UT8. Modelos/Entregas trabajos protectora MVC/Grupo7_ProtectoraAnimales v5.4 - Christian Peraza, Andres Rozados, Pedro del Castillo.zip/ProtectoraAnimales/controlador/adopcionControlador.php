<?php
//Incluyendo la vista de la tabla y la clase de modelo que se va a usar
include_once '../modelo/Adopcion.php';
include_once '../vista/MontadorTablas.php';

class ControladorAdopcion
{
    // Generador de la tabla correspondiente, que se muestra en la Vista
    public static function generarTabla()
    {
        $tablaGenerar=new TablaObjeto(new Adopcion()); // Se manda a la vista que pide la tabla usuario
        echo $tablaGenerar->imprimirTabla();
    }

    // Importa la vista para introducir adopcion 
    public static function introducirAdopcion()
    {
        include_once '../vista/adopcion/introducirAdopcion.php';

        $interfazIntroducirAdopcion = new vistaInsertarAdopcion();

        // Te muestra la vista de introducir usuario 
        $interfazIntroducirAdopcion -> imprimir();
    }

    // Crear una nueva adopción en la bbdd
    public static function insertarAdopcion()
    {
        try 
        {
            // Si en el formulario hay parámetros vacíos
            if ($_POST["idAnimal"] === "" || $_POST["idUsuario"] === "" || $_POST["fecha"] === "" || $_POST["razon"] === "") 
            {
                throw new Exception("No puede haber ningún campo vacío.", 1);
            }

            // Se crea el objeto y se llama a la función correspondiente para crear
            $insertarAdopcion = new Adopcion("", $_POST["idAnimal"], $_POST["idUsuario"], $_POST["fecha"], $_POST["razon"]);
            
            $insertarAdopcion -> crear();

            //Si no se lanza ningún error imprime el mensaje de introducción Correctamente hecha
            echo '<p class="mensaje-de-operacion-aceptada"">Adopción introducido correctamente.</p>';
        } 

            catch (Exception $e) 
            {
                echo '<p class="mensaje-de-error-operacion"">' . $e -> getMessage().'</p>';
            }
    }

    // Muestra el formulario para actualizar la Adopcion
    public static function mostrarVistaActualizarAdopcion()
    {
        // Actualizar fila
        try 
        {
            $adopcion = new Adopcion();
            
            //ActualizarFila contiene el id de la adopcion a modificar
            $adopcion = $adopcion -> obtieneDeId($_POST['actualizaFila'])[0]; //devuelve el objeto de tipo stdClass 

            //Se importa la clase necesaria para luego imprimir el formulario par actualizar los usuarios
            include_once '../vista/adopcion/actualizarFilaAdopcion.php';

            $formularioActualizar = new ActualizarVistaUsuario($adopcion);

            $formularioActualizar -> imprimir();

        } 
        
            catch (Exception $e) 
            {
                echo $e;
            }
    }

    // Contiene la lógica para actualizar en la BBDD la adopcion recibida por POST
    public static function actualizarAdopcion()
    {
        // Creando objeto de tipo Adopcion el cual contiene la funcion actualizar proviniente del Crud
        $actualizarAdopcion = new Adopcion($_POST['id'], $_POST['idAnimal'], $_POST['idUsuario'], $_POST['fecha'], $_POST['razon']);
        
        // Realizando la actualizacion
        $actualizarAdopcion->actualizar();
    }

    // Borra la adopcion de la fila correspondiente
    public static function borrarFila()
    {
        // Se requiere de la creacion de un objeto Adopcion para usar el metodo borrar
        $adopcion = new Adopcion('', "", "", "", "");

        try 
        {
            // BorrarFila corresponde al id de Adopcion
            $adopcion -> borrar($_POST['borrarFila']);
        } 
        
            catch (Exception $e) 
            {
                echo $e;
            }
    }
}

// Llamadas a las funciones cuando se pulsan los botones correspondientes
if (isset($_POST['reclamoTabla'])) 
{
    ControladorAdopcion::generarTabla();
}

if (isset($_POST['botonIntroducirPulsado'])) 
{
    ControladorAdopcion::introducirAdopcion();
}

if (isset($_POST['botonInsertarPulsado'])) 
{
    ControladorAdopcion::insertarAdopcion();
}

if (isset($_POST['actualizaFila'])) 
{
    ControladorAdopcion::mostrarVistaActualizarAdopcion();
}

if (isset($_POST['id'])) 
{
    ControladorAdopcion::actualizarAdopcion();
}

if (isset($_POST['borrarFila'])) 
{
    ControladorAdopcion::borrarFila();
}
?>