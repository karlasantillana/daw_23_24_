<head>
    <link rel = "stylesheet" href = "../styles/Vistas_Tablas.css">
    <style>
        body 
        {
            opacity: 0;
            transition: opacity 1s ease;
        }

        body.loaded 
        {
            opacity: 1;
        }
    </style>

    <script>
        window.addEventListener('load', function () 
        {
            document.body.classList.add('loaded');
        });
    </script>
</head>
<header>
    <nav>
        <form id="formularioBotones" action="controladorOrquestador.php" method="POST">
            <button name="botonPulsado" value="Usuario">Usuarios</button>
            <button name="botonPulsado" value="Animal">Animales</button>
            <button name="botonPulsado" value="Adopcion">Adopciones</button>
        </form>
    </nav>
</header>