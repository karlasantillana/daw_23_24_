<?php

// Genera la tabla para insertar en la BBDD una Adopción
class vistaInsertarAdopcion
{
    public function __construct(){}

    public function imprimir()
    {
        echo 
        '
        <div class = "contenedor-form">
        <h1 class = "titulo">Introducir Nuevo Usuario</h1>
            <div class = "contenedor-form">
                <form action="http://localhost/ProtectoraAnimales/controlador/controladorOrquestador.php" method="POST">
                    <label for="">Id Animal</label>
                    <input type="text" name="idAnimal"><br>
    
                    <label for="">Id Usuario</label>
                    <input type="text" name="idUsuario"><br>
    
                    <label for="">Fecha</label>
                    <input type="date" name="fecha"><br>
    
                    <label for="">Razon</label>
                    <input type="text" name="razon"><br>

                    <button name="botonInsertarPulsado" value="1">Insertar Adopcion</button>
                    <input type="hidden" name="nombreTabla" value="Adopcion">

                </form>
            </div>
        </div>';
    }
}
?>