<?php
class ActualizarVistaUsuario
{
    private $valoresInput;

    // Recibe como parametro un objeto de stdClass obtenedido de la funcion obtieneDeId del objeto Usuario
    public function __construct($valoresInput)
    {
        $this -> valoresInput = $valoresInput;
    }
    
    public function imprimir()
    {
        echo 
        '
        <div class = "contenedor-form"> 
            <div class = "contenedor-form">
                <form action="http://localhost/ProtectoraAnimales/controlador/controladorOrquestador.php" method="POST">
                    <label for="">ID_Animal</label>
                    <input type="text" name="idAnimal" value="'.$this->valoresInput->idAnimal.'">
    
                    <label for="">ID_Usuario</label>
                    <input type="text" name="idUsuario" value="'.$this->valoresInput->idUsuario.'">
    
                    <label for="">Fecha</label>
                    <input type="date" name="fecha" value="'.$this->valoresInput->fecha.'">
                    
                    <label for="">Razón</label>
                    <input type="text" name="razon" value="'.$this->valoresInput->razon.'">
                
                    <button>Actualizar Adopcion</button>
                    <input type="hidden" name="id" value="'.$this->valoresInput->id.'">
                    <input type="hidden" name="nombreTabla" value="Adopcion">
                </form>
            </div>
        </div>';
    }
}
?>