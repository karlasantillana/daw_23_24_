<?php
class ActualizarVistaUsuario
{

    private $valoresInput;

    //Recibe como parametro un objeto de stdClass obtenedido de la funcion obtieneDeId del objeto Usuario
    public function __construct($valoresInput)
    {
        $this -> valoresInput = $valoresInput;
    }
    
    public function imprimir()
    {
        echo 
        '
        <div class = "contenedor-form">
        <h1 class = "titulo">Actualizar Usuario</h1>
            
            <div class = "contenedor-form">
                <form action="http://localhost/ProtectoraAnimales/controlador/controladorOrquestador.php" method="POST">
                    <label for="">Nombre</label>
                    <input type="text" name="nombre" value="'.$this->valoresInput->nombre.'">

                    <label for="">Apellido</label>
                    <input type="text" name="apellido" value="'.$this->valoresInput->apellido.'">

                    <label for="">Sexo</label>
                    <input type="text" name="sexo" value="'.$this->valoresInput->sexo.'">

                    <label for="">Direccion</label>
                    <input type="text" name="direccion" value="'.$this->valoresInput->direccion.'">
                    
                    <label for="">Telefono</label>
                    <input type="text" name="telefono" value="'.$this->valoresInput->telefono.'">
                
                    <button>Actualizar usuario</button>
                    <input type="hidden" name="id" value="'.$this->valoresInput->id.'">
                    <input type="hidden" name="nombreTabla" value="Usuario">
                </form>
            </div>
        </div>';
    }
}
?>

