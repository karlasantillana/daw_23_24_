<?php

//clase que monta la tabla segun el objeto que recive por parametro
class TablaObjeto
{
    //Objeto que recibe un tipo del modelo para impriomir despues todos los datos de la tabla
    private $crud; 
    
    function __construct($objeto)
    {
        $this -> crud = $objeto; //es necesario usar un objeto del modelo
    }

    function imprimirTabla()
    {
        $filas = $this -> crud -> obtieneTodos();
        
        $resultado = "";
        
        //El nombreClase corresponde al nombre de la tabla que se quiere ver
        $nombreClase = get_class($this -> crud);

        $resultado .= '<div class="contendor-general">';
        $resultado .= '<h1 class="titulo">'.$nombreClase.'</h1>';
        
        //Formulario usado para los botones introducir Usuario actualizar y borrar
        $resultado .= '<form id="formularioTabla" action="controladorOrquestador.php" method="POST"></form>';
        
        //Cuando no hay ningun registro en la tabla
        if (empty($filas))
        {
            $resultado .= "<p>No hay ninguna fila en la tabla</p>";
        }
        
            //Cuando hay un registro en la tabla
            else
            {
                $resultado .= '<table>';
                $resultado .= "<tr>";
        
                //Impirmiendo el nombre de las columnas

                foreach ($filas[0] as $key => $value) 
                {
                    $resultado .= '<td>' . strtoupper($key) . '</td>';
                }
        
                $resultado .= "<td></td>";
                $resultado .= "<td></td>";
                $resultado .= "<tr>";
        
                //imprimiendo los valores de cada columna
                
                foreach ($filas as $cadaFila) 
                {
                    $resultado .= "<tr>";
        
                    foreach ($cadaFila as $valor) 
                    {
                        $resultado .= '<td>' . $valor . '</td>';
                    }
            
                    $resultado .= '<td><button class = "botones-form" type="submit" form="formularioTabla" name="actualizaFila" value="' . $cadaFila->id . '">Actualizar</button></td>'; //Se usa el id de la fila para saber que fila se debe actualizar
                    $resultado .= '<td><button class = "botones-form" type="submit" form="formularioTabla" name="borrarFila" value="' . $cadaFila->id . '">Borrar</button></td>'; //Se usa el id de la fila para saber que fila se debe borrar

                    $resultado .= "</tr>";
                }
                
                $resultado .= '</table>';
                
            }

        $resultado .= '<button type="submit"class="introducir-nuevo-registro" form="formularioTabla" name="botonIntroducirPulsado" value="1">Introducir '.$nombreClase.'</button>';
        $resultado .= '<input type="hidden" form="formularioTabla" name="nombreTabla" value="'.$nombreClase.'" >';
        $resultado .= '</div>';

        echo $resultado;
    }
}
?>