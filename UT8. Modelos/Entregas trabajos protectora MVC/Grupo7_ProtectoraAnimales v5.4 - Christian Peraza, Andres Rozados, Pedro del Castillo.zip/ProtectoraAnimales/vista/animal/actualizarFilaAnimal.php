<?php
class ActualizarVistaAnimal
{
    private $valoresInput;

    //Recibe como parametro un objeto de stdClass obtenedido de la funcion obtieneDeId del objeto Usuario
    public function __construct($valoresInput)
    {
        $this -> valoresInput = $valoresInput;
    }
    
    public function imprimir()
    {
        echo 
        '
        <div class = "contenedor-form">
        <h1 class = "titulo">Actualizar Usuario</h1>
            
            <div class = "contenedor-form">
                <form action="http://localhost/ProtectoraAnimales/controlador/controladorOrquestador.php" method="POST">
                    <label for="">Nombre</label>
                    <input type="text" name="nombre" value="'.$this->valoresInput->nombre.'">
    
                    <label for="">Especie</label>
                    <input type="text" name="especie" value="'.$this->valoresInput->especie.'">
    
                    <label for="">Raza</label>
                    <input type="text" name="raza" value="'.$this->valoresInput->raza.'">
    
                    <label for="">Genero</label>
                    <input type="text" name="genero" value="'.$this->valoresInput->genero.'">
    
                    <label for="">Color</label>
                    <input type="text" name="color" value="'.$this->valoresInput->color.'">
                    
                    <label for="">Edad</label>
                    <input type="number" name="edad" value="'.$this->valoresInput->edad.'">
    
                    <button>Actualizar Animal</button>
                    <input type="hidden" name="id" value="'.$this->valoresInput->id.'">
                    <input type="hidden" name="nombreTabla" value="Animal">
                </form>
            </div>
        </div>';
    }
}
?>
