<?php

//Genera la tabla para insertar en la BBDD un Animal
class IntroducirVistaAnimal
{

    public function __construct(){}
    
    public function imprimir()
    {
        echo 
        '
        <div class = "contenedor-form">
        <h1 class = "titulo">Introducir Nuevo Animal</h1>
            
            <div class = "contenedor-form">
                <form action="http://localhost/ProtectoraAnimales/controlador/controladorOrquestador.php" method="POST">
                    <label for="">Nombre</label>
                    <input type="text" name="nombre"><br>
            
                    <label for="">Especie</label>
                    <input type="text" name="especie"><br>
            
                    <label for="">Raza</label>
                    <input type="text" name="raza"><br>
            
                    <label for="">Genero</label>
                    <input type="text" name="genero"><br>
            
                    <label for="">Color</label>
                    <input type="text" name="color"><br>
            
                    <label for="">Edad</label>
                    <input type="number" name="edad"><br>

                    <button name="botonInsertarPulsado" value="1">Insertar Animal</button>
                    <input type="hidden" name="nombreTabla" value="Animal">

                </form>
            </div>
        </div>';
    }
}
?>