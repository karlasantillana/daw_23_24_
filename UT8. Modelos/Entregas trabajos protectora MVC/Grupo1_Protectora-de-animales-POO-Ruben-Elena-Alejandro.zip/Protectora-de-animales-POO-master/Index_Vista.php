<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style-index.css">
    <title>PROTECTORA DE ANIMALES</title>
</head>

<body>
    <h1>TABLAS:</h1>
    <a href="index.php?controlador=Animal">Animales</a>
    <a href="index.php?controlador=usuario">Usuarios</a>
    <a href="index.php?controlador=adopcion">Adopciones</a>
</body>

</html>