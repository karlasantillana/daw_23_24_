<?php
require_once "Conexion.php";
abstract class Crud extends Conexion
{
    private $tabla;

    function __construct($tabla)
    {
        $this->tabla = $tabla;
        parent::__construct();
    }

    function obtieneTodos()
    {
        $tab = $this->tabla;
        $conn = $this->conectar();

        $sql = "SELECT * FROM $tab;";
        $resultado = $conn->query($sql);
        $registros = $resultado->fetchAll(PDO::FETCH_OBJ);

        return $registros;
    }

    function obtieneDelID($id)
    {
        $tab = $this->tabla;
        $conn = $this->conectar();

        $sql = "SELECT * FROM $tab WHERE id = $id;";
        $resultado = $conn->query($sql);
        $registro = $resultado->fetchAll(PDO::FETCH_ASSOC);

        return $registro;
    }

    function borrar($id)
    {
        $tab = $this->tabla;
        $conn = $this->conectar();

        $sql = "DELETE FROM $tab WHERE id = $id;";
        $resultado = $conn->query($sql);
        $registro = $resultado->fetchAll(PDO::FETCH_ASSOC);

        return $registro;
    }

    abstract function crear();
    abstract function actualizar();

}
?>