<!DOCTYPE html>

<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROTECTORA</title>
</head>

<body>
    <h2>Adopciones</h2>

    <button onclick="location.href='../index.html'">Atrás</button>

    <?php
        require_once "../Modelo/Adopcion.php";
        $adopcion1 = new Adopcion();
        $adopciones = $adopcion1->obtieneTodos();
    ?>

    <form action="../Controlador/Adopcion_controlador.php" method='post'>
        <a href='../Controlador/Adopcion_controlador.php'><input class='input' type='submit' name='AñadirAd' value='Añadir'></a>
    </form> 

    <table>
        <tr>
            <td>Id</td>
            <td>Id Animal</td>
            <td>Id Usuario</td>
            <td>Fecha</td>
            <td>Razón</td>
        </tr>
        
    <?php
        foreach ($adopciones as $adopcion) {
    ?>

        </tr>
            <form action="../Controlador/Adopcion_controlador.php" method="post">
                <td><input class="input" type="number" name="id" value="<?= $adopcion->id ?>" readonly></td>
                <td><input class="input" type="text" name="idAnimal" value="<?= $adopcion->idAnimal ?>"></td>
                <td><input class="input" type="text" name="idUsuario" value="<?= $adopcion->idUsuario ?>"></td>
                <td><input class="input" type="date" name="fecha" value="<?= $adopcion->fecha ?>"></td>
                <td><input class="input" type="text" name="razon" value="<?= $adopcion->razon ?>"></td>
                <td><a href="../Controlador/Adopcion_controlador.php"><input class="input" type="submit" name="ModificarAd" value="Modificar"></a></td>
                <td><a href="../Controlador/Adopcion_controlador.php"><input class="input" type="submit" name="EliminarAd" value="Eliminar"></a></td>
            </form>
        </tr>

    <?php
        }
    ?>
    
    </table>
</body>

</html>