<!DOCTYPE html>

<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROTECTORA</title>
</head>

<body>
    <h2>Añadir Adopción</h2>
    
    <button onclick="location.href='Adopcion_controlador.php'">Atrás</button>

    <form action="../Controlador/Adopcion_controlador.php" method="post">
        Id Animal:
        <input class="input" type="number" name="idAnimal"></br>
        Id Usuario:
        <input class="input" type="number" name="idUsuario"></br>
        Fecha:
        <input class="input" type="date" name="fecha"></br>
        Razón:
        <input class="input" type="text" name="razon"></br>
        <input class="input" type="submit" name="EnviarAd" value="Enviar">
    </form>
</body>

</html>