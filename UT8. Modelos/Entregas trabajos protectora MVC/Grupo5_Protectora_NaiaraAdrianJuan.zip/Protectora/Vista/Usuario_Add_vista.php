<!DOCTYPE html>

<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROTECTORA</title>
</head>

<body>
    <h2>Añadir Usuario</h2>

    <button onclick="location.href='usuario_controlador.php'">Atrás</button>

    <form  action="../Controlador/Usuario_controlador.php" method="post">
        Nombre:
        <input class="input" type="text" name="nombre"></br>
        Apellido:
        <input class="input" type="text" name="apellido"></br>
        Sexo:
        <input class="input" type="text" name="sexo"></br>
        Dirección:
        <input class="input" type="text" name="direccion"></br>
        Teléfono:
        <input class="input" type="text" name="telefono"></br>
        <input class="input" type="submit" name="EnviarU" value="Enviar">
    </form>
</body>

</html>