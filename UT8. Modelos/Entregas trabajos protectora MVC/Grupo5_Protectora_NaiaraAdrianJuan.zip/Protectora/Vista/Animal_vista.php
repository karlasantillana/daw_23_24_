<!DOCTYPE html>

<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROTECTORA</title>
</head>

<body>
    <h2>Animales</h2>

    <button onclick="location.href='../index.html'">Atrás</button>

    <?php
        require_once "../Modelo/Animal.php";

        $animal1 = new Animal();
        $animales = $animal1->obtieneTodos();
    ?>

    <form action="../Controlador/Animal_controlador.php" method='post'>
        <a href='../Controlador/Animal_controlador.php'><input class='input' type='submit' name='AñadirAn' value='Añadir'></a>
    </form> 

    <table>
        <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th>Especie</th>
            <th>Raza</th>
            <th>Género</th>
            <th>Color</th>
            <th>Edad</th>
        </tr>
        
    <?php
       foreach ($animales as $animal) {
    ?>

        <tr>
            <form action="../Controlador/Animal_controlador.php" method="post">
                <td><input class="input" type="number" name="id" value="<?= $animal->id ?>" readonly></td>
                <td><input class="input" type="text" name="nombre" value="<?= $animal->nombre ?>"></td>
                <td><input class="input" type="text" name="especie" value="<?= $animal->especie ?>"></td>
                <td><input class="input" type="text" name="raza" value="<?= $animal->raza ?>"></td>
                <td><input class="input" type="text" name="genero" value="<?= $animal->genero ?>"></td>
                <td><input class="input" type="text" name="color" value="<?= $animal->color ?>"></td>
                <td><input class="input" type="number" name="edad" value="<?= $animal->edad ?>"></td>
                <td><a href="../Controlador/Animal_controlador.php"><input class="input" type="submit" name="ModificarAn" value="Modificar"></a></td>
                <td><a href="../Controlador/Animal_controlador.php"><input class="input" type="submit" name="EliminarAn" value="Eliminar"></a></td>
            </form>
        </tr>

    <?php    
        }
    ?>

    </table>
</body>

</html>