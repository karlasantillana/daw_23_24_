<!DOCTYPE html>

<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROTECTORA</title>
</head>

<body>
    <h2>Añadir Animal</h2>

    <button onclick="location.href='Animal_controlador.php'">Atrás</button>

    <form  action="../Controlador/Animal_controlador.php" method="post">
        Nombre:
        <input class="input" type="text" name="nombre"></br>
        Especie:
        <input class="input" type="text" name="especie"></br>
        Raza:
        <input class="input" type="text" name="raza"></br>
        Genero:
        <input class="input" type="text" name="genero"></br>
        Color:
        <input class="input" type="text" name="color"></br>
        Edad:
        <input class="input" type="number" name="edad"></br>
        <input class="input" type="submit" name="EnviarAn" value="Enviar">
    </form>
</body>

</html>