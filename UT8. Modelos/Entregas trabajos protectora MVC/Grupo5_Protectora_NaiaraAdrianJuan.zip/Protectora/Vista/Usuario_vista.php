<!DOCTYPE html>

<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROTECTORA</title>
</head>

<body>
    <h2>Usuarios</h2>

    <button onclick="location.href='../index.html'">Atrás</button>

    <?php
        require_once "../Modelo/Usuario.php";

        $usuario1 = new Usuario();
        $usuarios = $usuario1->obtieneTodos();
    ?>

    <form action="../Controlador/Usuario_controlador.php" method='post'>
        <a href='../Controlador/Usuario_controlador.php'><input class='input' type='submit' name='AñadirU' value='Añadir'></a>
    </form> 

    <table>
        <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Sexo</th>
            <th>Dirección</th>
            <th>Teléfono</th>
        </tr>

    <?php
        foreach ($usuarios as $usuario) {
            echo "<tr>";  
    ?>

        <tr>
            <form action="../Controlador/Usuario_controlador.php" method="post">
                <td><input class="input" type="number" name="id" value="<?= $usuario->id ?>" readonly></td>
                <td><input class="input" type="text" name="nombre" value="<?= $usuario->nombre ?>"></td>
                <td><input class="input" type="text" name="apellido" value="<?= $usuario->apellido ?>"></td>
                <td><input class="input" type="text" name="sexo" value="<?= $usuario->sexo ?>"></td>
                <td><input class="input" type="text" name="direccion" value="<?= $usuario->direccion ?>"></td>
                <td><input class="input" type="text" name="telefono" value="<?= $usuario->telefono ?>"></td>
                <td><a href="../Controlador/Usuario_controlador.php"><input class="input" type="submit" name="ModificarU" value="Modificar"></a></td>
                <td><a href="../Controlador/Usuario_controlador.php"><input class="input" type="submit" name="EliminarU" value="Eliminar"></a></td>
            </form>
        </tr>

    <?php
        }  
    ?>

    </table>
</body>

</html>
