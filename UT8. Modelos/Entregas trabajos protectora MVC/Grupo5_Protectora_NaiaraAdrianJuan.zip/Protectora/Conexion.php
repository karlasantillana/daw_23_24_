<?php

$servername = "localhost";
$port = 3307;
$database = "protectora_animales";
$username = "root";
$password = "";
$conn;

protected function conectar() {
    try {
        $this->conexion = new PDO("mysql:host={$this->host};port={$this->port};dbname={$this->database}", $this->username, $this->password);
        $this->conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("Conexión fallida: " . $e->getMessage());
    }

    return $this->conexion;
}
?>