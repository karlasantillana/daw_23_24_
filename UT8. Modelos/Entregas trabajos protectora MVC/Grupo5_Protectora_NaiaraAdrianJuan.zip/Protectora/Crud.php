<?php

abstract class Crud extends Conexion {
    private $tabla;
    protected $conexion;

    function __construct($tabla) {
        parent::conectar();
        $this->tabla = $tabla;
        $this->conexion = $this->conectar();
    }

    function obtieneDeID($id) {
        $sql = "SELECT * FROM {$this->tabla} WHERE id = ?";
        $consulta = $this->conexion->prepare($sql);
        $consulta->bindParam(1, $id);
        $consulta->execute();

        return $consulta->fetch(PDO::FETCH_OBJ);
    }

    function borrar($id) {
        $sql = "DELETE FROM {$this->tabla} WHERE id = ?";
        $consulta = $this->conexion->prepare($sql);
        $consulta->bindParam(1, $id);
        $consulta->execute();

        return $consulta->rowCount(); 

    abstract function crear();
    abstract function actualizar();
}

?>