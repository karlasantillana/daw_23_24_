<?php
include_once "../Core/Crud.php";

class Adopcion extends Crud
{
    private $idAnimal;
    private $idUsuario;
    private $fecha;
    private $razon;
    private const TABLA = "adopcion";


    public function __construct()
    {
        parent::__construct(Adopcion::TABLA);
    }

    public function __set(mixed $property, mixed $value)
    {
        $this->$property = $value;
    }

    public function __get(mixed $property)
    {
        return $this->$property;
    }


    public function crear()
    {
        $connection = $this->conectar();

        $sql = "INSERT INTO adopcion (idAnimal, idUsuario, fecha, razon) VALUES ( ?, ?, ?, ?)";
        $statement = $connection->prepare($sql);

        $statement->bindParam(1, $this->idAnimal);
        $statement->bindParam(2, $this->idUsuario);
        $statement->bindParam(3, $this->fecha);
        $statement->bindParam(4, $this->razon);

        $statement->execute();
    }

    public function actualizar()
    {
        $connection = $this->conectar();
        $statement = $connection->prepare("UPDATE adopcion SET idAnimal=?,idUsuario=?,fecha=?,razon=? WHERE id= ?");

        $statement->bindParam(1, $this->idAnimal);
        $statement->bindParam(2, $this->idUsuario);
        $statement->bindParam(3, $this->fecha);
        $statement->bindParam(4, $this->razon);
        $statement->bindParam(5, $this->id);

        $statement->execute();
    }
}
?>