<?php
include_once "../Core/Crud.php";
class Usuario extends Crud
{
    private $id;
    private $nombre;
    private $apellido;
    private $sexo;
    private $direccion;
    private $telefono;
    private $edad;
    const tabla = "usuarios";


    function __construct()
    {
        parent::__construct(Usuario::tabla);

    }

    public function __set($param, $valor)
    {
        $this->$param = $valor;
    }

    public function __get($param)
    {
        return $this->$param;
    }

    function crear()
    {

        $conn = $this->conectar();

        $sql = "INSERT INTO usuarios (id, nombre, apellido, sexo, direccion, telefono) 
        VALUES (:id , :nombre , :apellido , :sexo , :direccion , :telefono)";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $this->id);
        $stmt->bindParam(':nombre', $this->nombre);
        $stmt->bindParam(':apellido', $this->apellido);
        $stmt->bindParam(':sexo', $this->sexo);
        $stmt->bindParam(':direccion', $this->direccion);
        $stmt->bindParam(':telefono', $this->telefono);
        $stmt->execute();

    }

    function actualizar()
    {

        $conn = $this->conectar();

        $sql = "UPDATE usuarios
                SET nombre = :nom, apellido = :ape, sexo = :sexo, direccion = :dir, telefono = :telf
                WHERE id = $this->id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':nom', $this->nombre);
        $stmt->bindParam(':ape', $this->apellido);
        $stmt->bindParam(':sexo', $this->sexo);
        $stmt->bindParam(':dir', $this->direccion);
        $stmt->bindParam(':telf', $this->telefono);
        $stmt->execute();



    }

    function __toString()
    {
        return "Datos: " . $this->nombre;
    }
}
?>