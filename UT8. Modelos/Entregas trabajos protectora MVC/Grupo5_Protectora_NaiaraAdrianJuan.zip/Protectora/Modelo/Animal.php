<?php
    include_once "../Core/Crud.php";

    class Animal extends Crud
    {
        private $id;
        private $nombre;
        private $especie;
        private $raza;
        private $genero;
        private $color;
        private $edad;
        const tabla = "animal";

        function __construct()
        {
            parent::__construct(Animal::tabla);
        }

        public function __get($property)
        {
            return $this->$property;
        }

        public function __set($property, $value)
        {
            $this->$property = $value;
        }

        public function crear()
        {
            $sql = "INSERT INTO animal (nombre, especie, raza, genero, color, edad) VALUES ( ?, ?, ?, ?, ?, ?)";
            $conn = $this->conectar();

            $stmt = $conn->prepare($sql);


            $stmt->bindParam(1, $this->nombre);
            $stmt->bindParam(2, $this->especie);
            $stmt->bindParam(3, $this->raza);
            $stmt->bindParam(4, $this->genero);
            $stmt->bindParam(5, $this->color);
            $stmt->bindParam(6, $this->edad);

            $stmt->execute();
        }

        public function actualizar()
        {
            $conn = $this->conectar();
            $sql = "UPDATE animal SET nombre = ?, especie = ?, raza = ?, genero = ?, color = ?, edad = ? WHERE id = ?";
            $consulta = $conn->prepare($sql);

            $consulta->bindParam(1, $this->nombre);
            $consulta->bindParam(2, $this->especie);
            $consulta->bindParam(3, $this->raza);
            $consulta->bindParam(4, $this->genero);
            $consulta->bindParam(5, $this->color);
            $consulta->bindParam(6, $this->edad);
            $consulta->bindParam(7, $this->id);

            $consulta->execute();
        }
    }
?>