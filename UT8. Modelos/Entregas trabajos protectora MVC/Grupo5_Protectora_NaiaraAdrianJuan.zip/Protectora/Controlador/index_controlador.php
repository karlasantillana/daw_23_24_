<?php
    if (isset($_POST['Animal'])) {
        require_once "../Controlador/Animal_controlador.php";
    } elseif (isset($_POST['Usuario'])) {
        require_once "../Controlador/Usuario_controlador.php";
    } elseif (isset($_POST['Adopcion'])) {
        require_once "../Controlador/Adopcion_controlador.php";
    }
?>