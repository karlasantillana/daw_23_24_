<?php
    require_once "../Modelo/Adopcion.php";

    /* MODIFICAR UNA ADOPCIÓN */
    if (isset($_POST['ModificarAd'])) {
        $id = $_POST["id"];
        $idAnimal = $_POST["idAnimal"];
        $idUsuario = $_POST["idUsuario"];
        $fecha = $_POST["fecha"];
        $razon = $_POST["razon"];
        
        $adopcion = new Adopcion();
        $adopcion->id = $id;
        $adopcion->idAnimal = $idAnimal;
        $adopcion->idUsuario = $idUsuario;
        $adopcion->fecha = $fecha;
        $adopcion->razon =$razon;
        $adopcion->actualizar();

        require_once "../Vista/Adopcion_vista.php";
    }

    /* ELIMINAR UNA ADOPCIÓN */
    else if (isset($_POST['EliminarAd'])) {
        $id = $_POST["id"];
        $adopcionEl = new Adopcion();
        $adopcionEl->borrar($id); 

        require_once "../Vista/Adopcion_vista.php";  
    }

    /* FORMULARIO PARA AÑADIR UNA ADOPCIÓN */
    else if (isset($_POST['AñadirAd'])) {
        require_once "../Vista/Adopcion_Add_vista.php";
    }

    /* AÑADIR UNA ADOPCIÓN */
    else if (isset($_POST['EnviarAd'])){
        $idAnimal = $_POST["idAnimal"];
        $idUsuario = $_POST["idUsuario"];
        $fecha = $_POST["fecha"];
        $razon = $_POST["razon"];

        $adopcion = new Adopcion();
        $adopcion->idAnimal = $idAnimal;
        $adopcion->idUsuario = $idUsuario;
        $adopcion->fecha = $fecha;
        $adopcion->razon = $razon;
        $adopcion->crear();

        require_once "../Vista/Adopcion_vista.php";
    } 
    
    /* MOSTRAR PÁGINA */
    else {
        require_once "../Vista/Adopcion_vista.php";
    }
?>