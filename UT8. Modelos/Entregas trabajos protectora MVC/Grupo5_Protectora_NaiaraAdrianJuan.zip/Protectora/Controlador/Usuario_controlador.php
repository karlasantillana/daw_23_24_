<?php
    require_once "../Modelo/Usuario.php";

    /* MODIFICAR UN USUARIO */
    if (isset($_POST['ModificarU'])) {
        $id = $_POST["id"];
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $sexo = $_POST["sexo"];
        $direccion = $_POST["direccion"];
        $telefono = $_POST["telefono"];
        
        $usuario = new Usuario();
        $usuario->id = $id;
        $usuario->nombre = $nombre;
        $usuario->apellido = $apellido;
        $usuario->sexo = $sexo;
        $usuario->direccion = $direccion;
        $usuario->telefono =$telefono;
        $usuario->actualizar();

        require_once "../Vista/Usuario_vista.php";
    }

    /* ELIMINAR UN USUARIO */
    else if (isset($_POST['EliminarU'])) {
        $id = $_POST["id"];
        $usuarioEl = new Usuario();
        $usuarioEl->borrar($id); 

        require_once "../Vista/Usuario_vista.php"; 
    }

    /* FORMULARIO PARA AÑADIR UN USUARIO */
    else if (isset($_POST['AñadirU'])) {
        require_once "../Vista/Usuario_Add_vista.php";
    }

    /* AÑADIR UN USUARIO */
    else if (isset($_POST['EnviarU'])){
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $sexo = $_POST["sexo"];
        $direccion = $_POST["direccion"];
        $telefono = $_POST["telefono"];

        $usuario = new Usuario();
        $usuario->nombre = $nombre;
        $usuario->apellido = $apellido;
        $usuario->sexo = $sexo;
        $usuario->direccion = $direccion;
        $usuario->telefono =$telefono;
        $usuario->crear();
        require_once "../Vista/Usuario_vista.php";
    }

    /* MOSTRAR PÁGINA */
    else {
        require_once "../Vista/Usuario_vista.php";
    }
?>