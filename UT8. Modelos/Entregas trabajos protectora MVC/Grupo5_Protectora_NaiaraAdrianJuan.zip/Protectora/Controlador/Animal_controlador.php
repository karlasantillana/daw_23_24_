<?php
    require_once "../Modelo/Animal.php";

    /* MODIFICAR UN ANIMAL */
    if (isset($_POST['ModificarAn'])) {
        $nombre = $_POST["nombre"];
        $especie = $_POST["especie"];
        $raza = $_POST["raza"];
        $genero = $_POST["genero"];
        $color = $_POST["color"];
        $edad = $_POST["edad"];
        $id = $_POST["id"];
        
        $animal = new Animal();
        $animal->id = $id;
        $animal->nombre = $nombre;
        $animal->especie = $especie;
        $animal->raza = $raza;
        $animal->genero = $genero;
        $animal->color =$color;
        $animal->edad = $edad;
        $animal->actualizar();

        require_once "../Vista/Animal_vista.php";
    }

    /* ELIMINAR UN ANIMAL */
    else if (isset($_POST['EliminarAn'])) {
        $id = $_POST["id"];
        $animalEl = new Animal();
        $animalEl->borrar($id); 

        require_once "../Vista/Animal_vista.php"; 
    }

    /* FORMULARIO PARA AÑADIR UN ANIMAL */
    else if (isset($_POST['AñadirAn'])) {
        require_once "../Vista/Animal_Add_vista.php";   
    }

    /* AÑADIR UN ANIMAL */
    else if (isset($_POST['EnviarAn'])){
        $nombre = $_POST["nombre"];
        $especie = $_POST["especie"];
        $raza = $_POST["raza"];
        $genero = $_POST["genero"];
        $color = $_POST["color"];
        $edad = $_POST["edad"];

        $animal = new Animal();
        $animal->nombre = $nombre;
        $animal->especie = $especie;
        $animal->raza = $raza;
        $animal->genero = $genero;
        $animal->color =$color;
        $animal->edad = $edad;
        $animal->crear();
        
        require_once "../Vista/Animal_vista.php";
    }

    /* MOSTRAR PÁGINA */
    else {
        require_once "../Vista/Animal_vista.php";
    }
?>