Proyecto Animales Pedro, Lucía y Oscar
Estructura de carpetas: 
  -Controlador
  -Modelo
  -Vista
  index.php
  main.php
